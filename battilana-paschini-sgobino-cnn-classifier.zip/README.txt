File del progetto di Battilana Giovanni, Paschini Marzia, Sgobino Marco relativi al CNN Classifier.

Il documento PDF è corredato di 5 file in codice matlab relativi alle reti sviluppate dagli studenti. Nel documento è indicato a quale file corrisponde quale rete.
